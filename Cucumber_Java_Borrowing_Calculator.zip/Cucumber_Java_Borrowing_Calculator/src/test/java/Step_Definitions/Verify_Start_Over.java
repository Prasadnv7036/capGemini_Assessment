package Step_Definitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Verify_Start_Over extends BaseTest
{
	

//	@When("user click on We estimate you could borrow Start 	Over refresh logo")
//	public void user_click_on_we_estimate_you_could_borrow_start_over_refresh_logo() 
//	{
//	driver.findElement(By.xpath("(//button[@class='start-over']//span)[1]")).click();
//		
//	}
//
//	@Then("user get barrow calculator screen")
//	public void user_get_barrow_calculator_screen() {
//	    System.out.println("Successfully start over....");
//	}

	

}
