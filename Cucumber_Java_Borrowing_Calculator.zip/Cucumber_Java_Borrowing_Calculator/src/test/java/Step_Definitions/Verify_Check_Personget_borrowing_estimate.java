package Step_Definitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Verify_Check_Personget_borrowing_estimate
{
	public WebDriver driver;

	@When("user select on Single button")
	public void user_select_on_single_button() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
	Thread.sleep(3000);
	driver.manage().window().maximize();
	
	driver.get("https://www.anz.com.au/personal/home-loans/calculators-tools/much-borrow/");
	
	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	driver.findElement(By.xpath("//label[contains(.,'Single')]")).click();
	}

	@When("user select dropdown for Number of dependants zero")
	public void user_select_dropdown_for_number_of_dependants_zero() {
		
//		WebElement numberOfDependants = driver.findElement(By.xpath("//select[@class='non-keyboard-outline']"));
//		Select select = new Select(numberOfDependants);
//	   
//		select.selectByIndex(0);
	//	
	//driver.findElement(By.xpath("//select[@class='non-keyboard-outline']")).sendKeys("0");
	}

	@When("user click on Property you would like to buy home to live in button")
	public void user_click_on_property_you_would_like_to_buy_home_to_live_in_button() {
	   
		driver.findElement(By.xpath("//label[contains(.,'Home to live in')]")).click();
	}

	@When("user enter Your annual income \\(before tax) field ${int}")
	public void user_enter_your_annual_income_before_tax_field_$(Integer int1) {
	 driver.findElement(By.xpath("(//input[@type=\"text\"])[2]")).sendKeys("80000");
	}

	@When("user enter Your annual other income \\(optional) ${int}")
	public void user_enter_your_annual_other_income_optional_$(Integer int1)
	{
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[3]")).sendKeys("10000");   
	}

	@When("user enter Monthly living expenses ${int}")
	public void user_enter_monthly_living_expenses_$(Integer int1)
	{
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[6]")).sendKeys("500");     
	}

	@When("user enter Current home loan monthly ${int}")
	public void user_enter_current_home_loan_monthly_$(Integer int1) {
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[7]")).sendKeys("0");   
	  
	}

	@When("user enter Other loan monthly repayments ${int}")
	public void user_enter_other_loan_monthly_repayments_$(Integer int1) {
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[8]")).sendKeys("100");     
	}

	@When("user enter other commitments ${int}")
	public void user_enter_other_commitments_$(Integer int1) {
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[9]")).sendKeys("0");   
	}

	@When("user enter total credit card limits ${double}")
	public void user_enter_total_credit_card_limits_$(Double double1) {
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[10]")).sendKeys("10000");   
	}

	@When("user click on Work out how much i could borrow")
	public void user_click_on_work_out_how_much_i_could_borrow() {
		 driver.findElement(By.id("btnBorrowCalculater")).click();
	}

	@Then("user get borrowing estimate of ${double}.")
	public void user_get_borrowing_estimate_of_$(Double double1)
	{
	System.out.println("Successfully Verified");
	}

	
	
}
