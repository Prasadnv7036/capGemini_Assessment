package Step_Definitions;

import static org.testng.Assert.assertThrows;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Verify_Monthly_living_expenses_errorMsg extends BaseTest
{

	@When("user enter only Monthly living expenses ${int} and remaing fields empty")
	public void user_enter_only_monthly_living_expenses_$_and_remaing_fields_empty(Integer int1) {
		 driver.findElement(By.xpath("(//input[@type=\"text\"])[6]")).sendKeys("1");  
		 driver.findElement(By.id("btnBorrowCalculater")).click();
	}

	@Then("user get Based on the details you've entered, we're unable to give you an estimate of your borrowing power with this calculator. For questions, call us on {int} {int} {int}.")
	public void user_get_based_on_the_details_you_ve_entered_we_re_unable_to_give_you_an_estimate_of_your_borrowing_power_with_this_calculator_for_questions_call_us_on(Integer int1, Integer int2, Integer int3) {
	 
		WebElement errorMsg = driver.findElement(By.xpath("//b[.='1800 035 500']"));
      Assert.assertTrue(errorMsg.isDisplayed());
	}
}
