package borrowing_script;

public interface Automation_Constant {

}
